# NexaVest — Investment Platform Starter

A demo full-stack dashboard using React + Vite, Node.js + Express, Prisma and SQLite.

> **Demo only:** this project does not process real deposits, custody funds, promise returns, or automatically release withdrawals. Before using it with real money, integrate compliant payment/custody providers and obtain all required legal and regulatory approvals.

## Run locally

### Requirements
- Node.js 20+
- npm

### 1. Server

```bash
cd server
npm install
cp .env.example .env
# Edit .env and set a long random JWT_SECRET
npx prisma migrate dev --name init
npm run seed
npm run dev
```

The API runs on `http://localhost:4000` by default.

### 2. Client

In a second terminal:

```bash
cd client
npm install
cp .env.example .env
npm run dev
```

Open the Vite URL shown in the terminal (normally `http://localhost:5173`).

## Configuration

- `server/.env`: database, JWT secret, API port and allowed client origin.
- `client/.env`: API URL and WhatsApp support number.

Do not commit `.env` files or real secrets.

## Demo admin

The seed script creates `admin@nexavest.local` with the demo password `ChangeMe123!`. Change or remove this account before any real deployment.
